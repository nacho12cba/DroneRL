Follows Gazebo [style guide](http://gazebosim.org/tutorials?tut=contrib_code)
# Build Instructions

1. mkdir build
1. cd build
2. cmake ../
3. make
